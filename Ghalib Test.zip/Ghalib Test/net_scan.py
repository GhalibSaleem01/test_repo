#! /usr/bin/env python
import argparse
import aioping
import asyncio
import ipaddress
import functools

async def do_ping(host, timeout=5):
    try:
        delay = await aioping.ping(host, timeout) 
        print("Host: %s - Ping response in %s ms" %(host,delay))
    except TimeoutError:
        print("Host: %s - Timed out"%(host))

def run(args):
    timeout = args.timeout
    host = args.host
    concurrency_level = args.concurrency_level
    if(concurrency_level == None):
        concurrency_level = 8
    if(timeout == None):
        timeout = 0.5
    loop = asyncio.get_event_loop()
    if("/" not in host):
        loop.run_until_complete(do_ping(host, timeout))
    else:
        net4 = ipaddress.ip_network(host)
        task = []
        for ip in net4.hosts():
            k = do_ping(str(ip), timeout)
            task.append(k)
            if(len(task) == concurrency_level):
                loop.run_until_complete(asyncio.gather(*task))
                task=[]
        loop.run_until_complete(asyncio.gather(*task))
    
def main():
    parser=argparse.ArgumentParser(description="Taking ping command")
    parser.add_argument("-host",help="Host IP" ,dest="host", type=str, required=False)
    parser.add_argument("-c",help="Concurrency Level" ,dest="concurrency_level", type=int, required=False)
    parser.add_argument("-t",help="Timeout" ,dest="timeout", type=float, required=False)
    parser.set_defaults(func=run)
    args=parser.parse_args()
    args.func(args)

if __name__=="__main__":
    main()



